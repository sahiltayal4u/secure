      <footer>
        <div class="row d-flex justify-content-center">
          <div class="col-lg-10">
            <p>Protected by <strong><a href="https://codecanyon.net/item/project-security-website-security-antivirus-firewall/15487703?ref=Antonov_WEB" target="_blank">Project SECURITY</a></strong></p>
          </div>
        </div>
      </footer>
    
    </div>
	
  </body>
</html>